<?php

class User_model {
    private $nama = 'Juwita Mayasari';

    public function  getUser()
    {
        return $this->nama;
    }
}