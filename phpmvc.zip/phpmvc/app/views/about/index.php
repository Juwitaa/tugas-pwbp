<div class="container text-center">
    <h1 class="mt-4">Perkenalkan</h1>
    <img src="<?= BASEURL; ?> ../img/a.jpg"width='25%' class="rounded-circle shadow" > 
    <p>hallo nama saya <?= $data['nama']; ?>,pekerjaan saya adalah <?= $data['pekerjaan'] ?>
</div>