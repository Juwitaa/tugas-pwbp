<div class="container">
    <div class="jumbotron mt-4">
    <h1 class="display-4">selamat datang di website saya</h1>
    <p class="lead">Hallo nama saya <?= $data['nama']; ?></p>
     <hr class="my-4">
     <p>Website ini adalah website ternama yang hanya dibuat oleh orang Ternama </p>
     <a class="btn btn-primary btn-lg" href="#" role="button">Selengkapnya</a>
     </div>
</div>